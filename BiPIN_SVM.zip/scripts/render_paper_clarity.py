"""Improve result communication without fitting models or changing raw results."""
from pathlib import Path
import csv,json,hashlib,io,subprocess,shutil,argparse
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,black,white
from pypdf import PdfReader,PdfWriter
from pypdf.generic import ContentStream,NameObject

project=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,default=project/'runs/paper_figures')
parser.add_argument('--pdftoppm',default=shutil.which('pdftoppm'))
args=parser.parse_args()
figures=args.out.resolve();figures.mkdir(parents=True,exist_ok=True)
rows=list(csv.DictReader((project/'results/reference/main/paired_ci.csv').open(encoding='utf-8')))
datasets=['Bearing diagnosis','Breast cancer','Synthetic shift','Wine']
W,H=493.23,180
dst=figures/'paired_primary_gains.pdf'
c=canvas.Canvas(str(dst),pagesize=(W,H))
c.setTitle('Primary paired performance gains')
blue=HexColor('#0072B2')
# Equal x scales and common zero line in both panels. Units are percentage points.
for panel,(metric,title) in enumerate([('balanced_accuracy','(a) Balanced accuracy'),('macro_f1','(b) Macro-F1')]):
    left=panel*246.6
    x0,x1=left+74,left+235
    def xx(v):return x0+(v+5)/28*(x1-x0)
    c.setFillColor(black);c.setFont('Helvetica',9)
    c.drawCentredString(left+129,164,title)
    c.setStrokeColor(HexColor('#A5A5A5'));c.setDash(2,2);c.setLineWidth(.5)
    c.line(xx(0),42,xx(0),151);c.setDash()
    for i,dataset in enumerate(datasets):
        y=140-i*28
        r=next(r for r in rows if r['dataset']==dataset and r['metric']==metric)
        m,lo,hi=[100*float(r[k]) for k in ['mean_difference','ci_low','ci_high']]
        assert lo<=m<=hi and int(r['n'])==10
        c.setFillColor(black);c.setFont('Helvetica',7.5)
        c.drawRightString(x0-7,y-2.5,'Bearing' if i==0 else dataset)
        c.setStrokeColor(blue);c.setFillColor(blue);c.setLineWidth(1.2)
        c.line(xx(lo),y,xx(hi),y)
        for value in [lo,hi]:c.line(xx(value),y-2.5,xx(value),y+2.5)
        c.circle(xx(m),y,2.8,fill=1,stroke=0)
    c.setStrokeColor(HexColor('#666666'));c.setLineWidth(.5)
    c.line(x0,37,x1,37)
    c.setFillColor(black);c.setFont('Helvetica',7)
    for tick in [-5,0,5,10,15,20]:
        c.line(xx(tick),37,xx(tick),34)
        c.drawCentredString(xx(tick),24,str(tick))
    c.setFont('Helvetica',8)
    c.drawCentredString((x0+x1)/2,9,'BiPIN-EK minus Clean-RBF (pp)')
c.showPage();c.save()

# All five groups remain visible, including the four exact zeros.
info=json.loads((project/'results/reference/main/bearing_selected_scales.json').read_text(encoding='utf-8'))
dst=figures/'group_scales_clear.pdf'
c=canvas.Canvas(str(dst),pagesize=(410.1175,243.98375))
c.setTitle('Effective feature scales by group')
x0,x1=125,355
def xx(v):return x0+v/1.5*(x1-x0)
names=['Time-domain','Spectral','Envelope','Operating','Condition proxies']
for i,(name,value) in enumerate(zip(names,info['group_mean_feature_scale'])):
    y=207-i*34
    c.setFillColor(black);c.setFont('Helvetica',10)
    c.drawRightString(x0-12,y-3,name)
    c.setStrokeColor(HexColor('#A0A0A0'));c.setLineWidth(.8)
    c.line(x0,y,xx(value),y)
    c.setStrokeColor(blue);c.setFillColor(blue)
    c.circle(xx(value),y,3.6,fill=bool(value),stroke=1)
    c.setFillColor(black);c.drawString(xx(value)+9,y-3,f'{value:g}')
c.setStrokeColor(HexColor('#666666'));c.setLineWidth(.6);c.line(x0,51,x1,51)
c.setFont('Helvetica',9);c.setFillColor(black)
for t in [0,.5,1,1.5]:
    c.line(xx(t),51,xx(t),47)
    c.drawCentredString(xx(t),33,f'{t:g}')
c.setFont('Helvetica',10);c.drawCentredString((x0+x1)/2,13,'Effective feature scale')
c.showPage();c.save()

# Replace only the two axis-text blocks of the existing vector scatter plot.
# The scatter points, fitted visual guide, limits and tick labels stay identical.
original=project/'paper_figures/source/margin_noise_relation.pdf'
reader=PdfReader(original);page=reader.pages[0]
stream=ContentStream(page.get_contents(),reader)
newops=[];block=None;removed=0
for operands,operator in stream.operations:
    if operator==b'BT':block=[(operands,operator)]
    elif block is not None:
        block.append((operands,operator))
        if operator==b'ET':
            contents=' '.join(str(a) for a,o in block)
            if 'Clean-model uncertainty' in contents or 'erturbation standar' in contents:removed+=1
            else:newops.extend(block)
            block=None
    else:newops.append((operands,operator))
assert removed==2
stream.operations=newops;page[NameObject('/Contents')]=stream
overlay=io.BytesIO()
c=canvas.Canvas(overlay,pagesize=(float(page.mediabox.width),float(page.mediabox.height)))
c.setFont('Helvetica',10)
c.drawCentredString(233,9.278125,'Clean-model ambiguity')
c.saveState();c.translate(14,137);c.rotate(90)
c.drawCentredString(0,0,'Perturbation magnitude');c.restoreState()
c.showPage();c.save();overlay.seek(0)
page.merge_page(PdfReader(overlay).pages[0])
writer=PdfWriter();writer.add_page(page)
with (figures/'margin_noise_relation_clear.pdf').open('wb') as f:writer.write(f)

provenance={'figure4':{'source':'results/reference/main/paired_ci.csv','estimator':'mean of ten paired repetition differences','interval':'marginal 95% Student-t CI, df=9, no multiplicity adjustment','transform':'values multiplied by 100 to express percentage points; BAcc and macro-F1 only; AUC remains in Table 3','encoding':'point=mean, horizontal interval=CI; same x axis; dashed zero line','note':'zero-width intervals on two datasets remain exact zeros; these are not equivalence tests'},
 'figure7a':{'source':'results/reference/main/bearing_selected_scales.json','transform':'none','values':info['group_mean_feature_scale'],'encoding':'horizontal point/stem chart; exact zeros retained'},
 'figure7b':{'source':'paper_figures/source/margin_noise_relation.pdf','source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'transform':'replace two axis-text blocks only; all graphical data and original fitted guide retained','interpretation':'generator-imposed relation; not independent mechanism evidence'},
 'renderer':'ReportLab vector drawing; pypdf for label-only vector revision','data_or_model_changes':False}
(figures/'clarity_revision_provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
if args.pdftoppm:
    for name in ['paired_primary_gains','group_scales_clear','margin_noise_relation_clear']:
        subprocess.run([str(args.pdftoppm),'-png','-r','220','-singlefile',str(figures/(name+'.pdf')),str(figures/name)],check=True)
else:
    print('PDFs saved. Optional PNG previews need pdftoppm on PATH or --pdftoppm.')
print(json.dumps(provenance,indent=2))
