"""Run the four kernel behavior tests with only NumPy installed.

Only the two kernel functions are compiled from the actual scientific core's
AST. This checks their behavior, without importing the model-fitting dependency
stack. It does not validate the full core import, train SVMs or reproduce metrics.
"""
from pathlib import Path
import ast
import importlib.util
import json
import sys
import types
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
source = ROOT / "bipin/core.py"
tree = ast.parse(source.read_text(encoding="utf-8"))
names = {"expected_rbf_kernel", "clean_rbf_kernel"}
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in nodes} == names
module = types.ModuleType("bipin.core")
module.np = np
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), "exec"), module.__dict__)
sys.modules["bipin.core"] = module
spec = importlib.util.spec_from_file_location("kernel_behavior_tests", ROOT / "tests/test_kernel.py")
tests = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(tests)
suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
result = unittest.TextTestRunner(verbosity=2).run(suite)
report = {
    "status": "PASS" if result.wasSuccessful() else "FAIL",
    "mode": "AST-extracted actual kernels; NumPy only",
    "tests_run": result.testsRun,
    "numpy_version": np.__version__,
    "scope": "Four kernel behaviors only; no full core import or SVM fit.",
}
out = ROOT / "runs/kernel_minimal_check.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(report, indent=2), encoding="utf-8")
raise SystemExit(0 if result.wasSuccessful() else 1)
