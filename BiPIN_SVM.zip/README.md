# BiPIN-SVM reproduction code

Companion code for **Knowledge-Guided Covariance Selection for Expected-Kernel Support Vector Machines under Distribution Shift**.

This repository contains the four-dataset experiment, matched-candidate bearing component checks, frozen reference outputs, numerical verification and figure materials. It can be uploaded as a standalone repository. No manuscript source, private account, credentials, author-specific path or GPU is required.

The bearing benchmark is a controlled **feature-level simulation**, not measured-machine data. Validation and test conditions share a prescribed proxy-remapping family. Covariance budgets are fixed design settings. The component evidence does not establish an additional balanced-accuracy or macro-F1 benefit from sample-dependent variance allocation.

## Install

The recorded experiment environment is Python **3.12.14**. Use a new environment and the exact package lock:

    python -m venv .venv
    .venv\Scripts\Activate.ps1
    python -m pip install -r requirements-lock.txt

On Linux/macOS activate with: source .venv/bin/activate.
The directly used packages are in requirements.txt; the lock also records transitive dependencies. Installation needs a package index or compatible wheel source.

Breast Cancer Wisconsin Diagnostic and Wine are loaded from scikit-learn's installed example data; synthetic and bearing-feature data are generated locally. The experiments need no external data download.

## Verify before fitting

From the repository root:

    # Standard library only: frozen hashes, keys and arithmetic.
    python reproduce.py verify

    # NumPy only: four behavior checks on the actual two kernel functions.
    python scripts/check_kernel_minimal.py

    # With the complete locked scientific environment installed:
    python -m unittest discover -s tests -v
    python reproduce.py smoke

The minimal kernel check compiles only the two kernel functions from bipin/core.py and runs the same four behavior assertions. It does not validate a full scientific-stack import, train an SVM or reproduce predictive metrics. The ordinary unit-test command imports the full implementation.

The smoke command fits one exact published repetition on four datasets and compares 16 final models with frozen seed-0 metrics. It is not the complete ten-repetition study.

## Run the experimental protocol

    # Main study: 4 datasets x 4 methods x 10 paired repetitions.
    python reproduce.py main

    # Bearing component comparisons, using the ten frozen repetition seeds.
    python reproduce.py ablation

Both default to seeds 0 through 9 and write to runs/main/ or runs/ablation/, which are ignored by Git. Use --out to select another output directory. Options --repeats and --start support partial debugging; a partial run is not the published protocol. A single-repetition run leaves sample SD and confidence limits blank because these cannot be estimated.

The main study contains 2500 SVM fits, including 160 final method fits. Complete-procedure search counts differ: Fixed-Gaussian evaluates 3 candidates, Adaptive-no-knowledge 15, and BiPIN-EK 39, 33 or 27 according to group count. These comparisons do not isolate one covariance-design component.

Component comparisons keep the operating group immutable and compare Full, shuffled mutable groups, unit mutable budgets and a constant root-mean-square sample factor, with the clean model as a reference. Each covariance variant evaluates 39 attempts corresponding to 34 distinct covariance matrices per repetition. The constant-factor control preserves total variance for each matching candidate.

Protocol, seeds, groups, budgets, selection weights, tie order, tolerances and iteration limits are in configs/published_protocol.json. The scientific core uses log-space diagonal normalization, without a pairwise denominator floor.

## Aggregate results and rebuild figures

    python reproduce.py aggregate --raw runs/main/results_raw.csv --out runs/main_reaggregated
    python reproduce.py figures

The figures command rebuilds original mean/SD plots, model diagnostics and illustrative waveforms. It reads frozen aggregates and refits only the seed-0 bearing models needed for diagnostics, comparing their metrics with frozen values. To use a new main study, pass --reference runs/main.

The current article uses a paired-gain plot and revised diagnostic labels. Rebuild them **without refitting**:

    python -m pip install -r scripts/requirements-figures.txt
    python scripts/render_paper_clarity.py

Outputs go to runs/paper_figures/. PDF is always produced; optional PNG previews need pdftoppm on PATH or its executable path through --pdftoppm. Option --out changes the output folder. The script reads frozen paired intervals, group scales and the original vector diagnostic; it does not infer new point-level data from an image.

Current Figure 4 uses **paired mean differences and marginal 95% Student-t confidence intervals**, in percentage points. These differ from the original mean/SD plots. Figure 7 retains five groups, including four exact zeros. Its sample-level relation is imposed by the covariance generator, not independent evidence of a learned mechanism.

The paper_figures/snapshots/ folder contains current experimental figure layouts, including both 3D heatmaps. Their source mapping is in paper_figures/provenance.json. The parameter heatmap retains 39 candidate means over ten seeds. The 3D confusion chart preserves the original displayed two-decimal proportions, not unrounded estimates.

Standalone, data-frozen TikZ sources for the two 3D layouts are in paper_figures/source/. With TeX installed, after creating runs/paper_figures/:

    pdflatex -interaction=nonstopmode -halt-on-error -output-directory=runs/paper_figures paper_figures/source/parameter_space_heatmap_3d.tex
    pdflatex -interaction=nonstopmode -halt-on-error -output-directory=runs/paper_figures paper_figures/source/bearing_confusion_3d.tex

These compile the frozen visual specification; they do not recalculate selection. Candidate records remain in the reference CSV. The article workflow drawing is native manuscript LaTeX and is outside this code-only repository.

## Frozen evidence

| Evidence | File |
| --- | --- |
| Dataset sizes and protocol | configs/published_protocol.json |
| Main repetition-level metrics | results/reference/main/results_raw.csv |
| Main means and sample SD | results/reference/main/results_summary.csv |
| Main paired confidence intervals | results/reference/main/paired_ci.csv |
| Classification-utility differences | results/reference/main/utility_gain.csv |
| Seed-0 group scales | results/reference/main/bearing_selected_scales.json |
| Component repetition-level metrics | results/reference/ablation/results_raw.csv |
| Component means and sample SD | results/reference/ablation/results_summary.csv |
| Component paired intervals | results/reference/ablation/paired_ci.csv |
| All retained covariance candidates | results/reference/ablation/candidate_scores.csv |

The verify command independently recalculates means, sample SD, paired Student-t intervals and utility arithmetic with the standard library. It checks 39/34 candidate counts, total-variance matching and Full-to-main consistency. Intervals are marginal without multiplicity adjustment.

Frozen outputs are not overwritten by execution. Numerical tolerances are explicit. Timing columns are recorded logs, not a controlled hardware benchmark. Repeated public-data splits reuse observations; their intervals measure split variability rather than independent population sampling.

## What was validated

The historical docs/validation_summary.json records full-environment checks: frozen arithmetic, four kernel tests, one main repetition, one component repetition and original figure regeneration. The entire ten-repetition study was not rerun in that packaging check.

The current docs/package_validation_2026-10-30.json records frozen verification, the NumPy-only four-kernel check and current clarity-layout PDF generation. The full scientific stack and SVM experiments were not rerun in this packaging runtime. These scopes must not be combined into a claim of a new full replication.

MANIFEST.sha256.json hashes all distributed files except itself. Generated runs, caches and local environments are excluded.

## Sources and tool provenance

- Breast Cancer Wisconsin Diagnostic: [UCI record](https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic), DOI 10.24432/C5DW2B.
- Wine: [UCI record](https://archive.ics.uci.edu/dataset/109/wine), DOI 10.24432/C5PC7J.
- Adopted distributional-kernel construction: Muandet et al., [Learning from Distributions via Support Measure Machines](https://proceedings.neurips.cc/paper/2012/hash/9bf31c7ff062936a96d3c8bd1f8f2ff3-Abstract.html), 2012.
- The Scientific Visualization procedural skill assisted figure preparation. Its tool reference is Kassis et al., [Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents](https://arxiv.org/abs/2609.00065), 2026. This tool acknowledgment is separate from the kernel-method source.

Funding is in FUNDING.txt. No public repository URL or software DOI has been assigned.

## Licensing status

The authors have not selected a software license. No open-source reuse permission is implied; the authors should choose the intended licensing terms before granting those rights. This does not prevent repository upload. Public datasets retain their source licenses.
