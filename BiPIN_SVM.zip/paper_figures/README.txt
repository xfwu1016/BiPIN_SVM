Current article experimental-figure materials

snapshots/ contains vector PDF and available PNG/SVG copies of the current
paired primary-metric differences, parameter-space 3D heatmap, 3D confusion
comparison and two covariance diagnostic panels.

source/ contains the original vector ambiguity/magnitude diagnostic for label
revision, original two-decimal confusion proportions, the 39-candidate parameter
summary and frozen standalone TikZ specifications for the two 3D layouts.

provenance.json maps outputs to recorded sources. These presentation materials
do not refit models, produce new experimental results, estimate unrounded
confusion probabilities, or establish performance beyond the evaluated condition
family. Current clarity renderer: scripts/render_paper_clarity.py.
