"""Portable repository entry point; run --help for commands."""
from bipin.cli import main

if __name__ == "__main__":
    main()
