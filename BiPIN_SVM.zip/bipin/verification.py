"""Independent, standard-library verification of the frozen result tables."""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics

METRICS = ["balanced_accuracy", "macro_f1", "auc"]


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def t975_df9():
    """Numerically invert the df=9 Student-t CDF without SciPy."""
    df = 9
    normalizer = math.gamma(5) / (math.sqrt(df * math.pi) * math.gamma(4.5))

    def density(x):
        return normalizer * (1 + x * x / df) ** (-5)

    def integral(b):
        def simpson(a, b, fa, fm, fb):
            return (b - a) * (fa + 4 * fm + fb) / 6

        def refine(a, b, fa, fm, fb, value, tolerance, depth):
            middle = (a + b) / 2
            left_mid, right_mid = (a + middle) / 2, (middle + b) / 2
            fl, fr = density(left_mid), density(right_mid)
            left = simpson(a, middle, fa, fl, fm)
            right = simpson(middle, b, fm, fr, fb)
            if depth == 0 or abs(left + right - value) <= 15 * tolerance:
                return left + right + (left + right - value) / 15
            return refine(a, middle, fa, fl, fm, left, tolerance / 2, depth - 1) + refine(middle, b, fm, fr, fb, right, tolerance / 2, depth - 1)

        fa, fm, fb = density(0), density(b / 2), density(b)
        return refine(0, b, fa, fm, fb, simpson(0, b, fa, fm, fb), 1e-12, 20)

    low, high = 0.0, 10.0
    for _ in range(50):
        midpoint = (low + high) / 2
        if 0.5 + integral(midpoint) < 0.975:
            low = midpoint
        else:
            high = midpoint
    return (low + high) / 2


def close(a, b, tolerance=1e-10):
    error = abs(float(a) - float(b))
    if error > tolerance:
        raise AssertionError(f"Numeric mismatch: {a} versus {b} (absolute error {error})")
    return error


def verify_frozen(root):
    root = Path(root)
    reference = root / "results/reference"
    provenance = json.loads((root / "docs/source_provenance.json").read_text(encoding="utf-8"))
    for name, expected in provenance["frozen_files"].items():
        actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
        if actual != expected:
            raise AssertionError(f"Frozen-file hash changed: {name}")
    main = read_csv(reference / "main/results_raw.csv")
    component = read_csv(reference / "ablation/results_raw.csv")
    main_keys = {(r["dataset"], int(r["seed"]), r["method"]) for r in main}
    component_keys = {(int(r["seed"]), r["method"]) for r in component}
    if len(main) != len(main_keys) or len(main) != 160:
        raise AssertionError("Expected 160 unique main experiment rows")
    if len(component) != len(component_keys) or len(component) != 50:
        raise AssertionError("Expected 50 unique retained component rows")
    main_map = {(r["dataset"], int(r["seed"]), r["method"]): r for r in main}
    component_map = {(int(r["seed"]), r["method"]): r for r in component}
    datasets = {"Bearing diagnosis", "Breast cancer", "Synthetic shift", "Wine"}
    methods = {"Clean-RBF", "Fixed-Gaussian", "Adaptive-no-knowledge", "BiPIN-EK"}
    component_methods = {"Clean-RBF", "Full", "Shuffled-perturbable-groups", "Unit-budgets", "RMS-constant"}
    if {r["dataset"] for r in main} != datasets or {r["method"] for r in main} != methods:
        raise AssertionError("Unexpected main dataset or method labels")
    if {r["method"] for r in component} != component_methods:
        raise AssertionError("Exploratory or missing component method")
    max_summary_error = 0.0
    summary_cells = 0
    for family, raw in [("main", main), ("ablation", component)]:
        for row in read_csv(reference / family / "results_summary.csv"):
            group = [r for r in raw if r["method"] == row["method"] and (family != "main" or r["dataset"] == row["dataset"])]
            if {int(r["seed"]) for r in group} != set(range(10)):
                raise AssertionError("A result group does not have seeds0 through9")
            for metric in METRICS:
                values = [float(r[metric]) for r in group]
                max_summary_error = max(max_summary_error, close(statistics.mean(values), row[metric + "_mean"], 1e-12), close(statistics.stdev(values), row[metric + "_std"], 1e-12))
                summary_cells += 2
    critical = t975_df9()
    max_ci_error = 0.0
    intervals = 0

    def interval_check(values, row):
        nonlocal max_ci_error, intervals
        if len(values) != 10 or int(row["n"]) != 10:
            raise AssertionError("Frozen intervals require ten paired repetitions")
        mean = statistics.mean(values)
        half = critical * statistics.stdev(values) / math.sqrt(10)
        max_ci_error = max(max_ci_error, close(mean, row["mean_difference"]), close(mean - half, row["ci_low"]), close(mean + half, row["ci_high"]))
        intervals += 1

    for row in read_csv(reference / "main/paired_ci.csv"):
        values = [float(main_map[row["dataset"], seed, "BiPIN-EK"][row["metric"]]) - float(main_map[row["dataset"], seed, "Clean-RBF"][row["metric"]]) for seed in range(10)]
        interval_check(values, row)
    for row in read_csv(reference / "main/utility_gain.csv"):
        values = []
        for seed in range(10):
            full = main_map[row["dataset"], seed, "BiPIN-EK"]
            clean = main_map[row["dataset"], seed, "Clean-RBF"]
            values.append(float(full["balanced_accuracy"]) + 0.25 * float(full["macro_f1"]) - float(clean["balanced_accuracy"]) - 0.25 * float(clean["macro_f1"]))
        interval_check(values, row)
    for row in read_csv(reference / "ablation/paired_ci.csv"):
        values = [float(component_map[seed, "Full"][row["metric"]]) - float(component_map[seed, row["baseline"]][row["metric"]]) for seed in range(10)]
        interval_check(values, row)
    for seed in range(10):
        for metric in METRICS + ["lengthscale", "C"]:
            close(component_map[seed, "Full"][metric], main_map["Bearing diagnosis", seed, "BiPIN-EK"][metric], 1e-12)
        for method in component_methods - {"Clean-RBF"}:
            row = component_map[seed, method]
            if int(float(row["candidate_count"])) != 39 or int(float(row["unique_covariance_count"])) != 34 or int(row["final_fit_status"]) != 0:
                raise AssertionError("Component search count or solver status differs")
    candidates = read_csv(reference / "ablation/candidate_scores.csv")
    if len(candidates) != 1560:
        raise AssertionError("Expected 1560 retained covariance-candidate rows")
    max_rms_variance_error = 0.0
    for seed in range(10):
        by_method = {}
        for method in component_methods - {"Clean-RBF"}:
            group = [r for r in candidates if int(r["seed"]) == seed and r["method"] == method]
            if len(group) != 39 or len({r["covariance_sha256"] for r in group}) != 34:
                raise AssertionError("Distinct covariance count mismatch")
            if any(int(r["fit_status"]) != 0 for r in group):
                raise AssertionError("A frozen candidate did not converge")
            by_method[method] = {int(r["candidate_id"]): r for r in group}
            for row in group:
                score = float(row["balanced_accuracy"]) + 0.25 * float(row["macro_f1"]) - 0.0002 * float(row["variance_mean"])
                close(score, row["validation_score"], 1e-12)
        for identifier in range(1, 40):
            max_rms_variance_error = max(max_rms_variance_error, close(by_method["Full"][identifier]["variance_sum"], by_method["RMS-constant"][identifier]["variance_sum"], 1e-8))
    return {"status": "PASS", "main_rows": len(main), "component_rows": len(component),
            "summary_numeric_cells": summary_cells, "paired_intervals": intervals,
            "candidate_rows": len(candidates), "attempts_per_variant_seed": 39, "distinct_covariances_per_variant_seed": 34,
            "max_summary_error": max_summary_error, "max_ci_error": max_ci_error,
            "max_rms_variance_sum_error": max_rms_variance_error, "t975_df9": critical,
            "scope": "Frozen-file hashes, keys, summary arithmetic, marginal Student-t intervals, retained candidate counts, RMS matching and Full-to-main consistency. This command does not refit models."}
