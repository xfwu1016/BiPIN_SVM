"""Matched-candidate component checks, refactored from the final retained design."""
from pathlib import Path
import os,json,hashlib,time,warnings,platform,sys
import numpy as np
import pandas as pd
from scipy.stats import t
import scipy,sklearn,matplotlib
from sklearn.svm import SVC
from . import core as mod

def run(out: Path, repeats: int = 10, start_seed: int = 0, reference_csv: Path | None = None):
    if repeats < 1 or start_seed < 0:
        raise ValueError('repeats must be positive and start_seed nonnegative')
    OUT=Path(out).resolve();OUT.mkdir(parents=True,exist_ok=True)
    SOURCE=Path(mod.__file__)
    METHODS=['Full','Shuffled-perturbable-groups','Unit-budgets','RMS-constant']
    metrics=['balanced_accuracy','macro_f1','auc']
    fit_records=[];candidate_records=[];metadata=[];rows=[];predictions=[]

    def digest(array):
        array=np.asarray(array)
        return hashlib.sha256(array.tobytes()).hexdigest()

    def fit_kernel(k,y,c,seed,method,stage,candidate_id=None):
        coarse=stage=='candidate'
        model=SVC(C=c,kernel='precomputed',class_weight='balanced',max_iter=300 if coarse else 5000,
                  tol=5e-2 if coarse else 1e-4,cache_size=512,shrinking=False)
        model.fit(k,y)
        fit_records.append({'seed':seed,'method':method,'stage':stage,'candidate_id':candidate_id,
            'fit_status':int(model.fit_status_),'n_iter':model.n_iter_.tolist()})
        return model

    def make_kernel(x,var,l):
        k=mod.expected_rbf_kernel(x,x,var,var,l)
        k=.5*(k+k.T)
        k.flat[::len(k)+1]+=1e-9
        return k

    def flush():
        pd.DataFrame(rows).to_csv(OUT/'results_raw.csv',index=False)
        pd.DataFrame(candidate_records).to_csv(OUT/'candidate_scores.csv',index=False)
        (OUT/'fit_records.json').write_text(json.dumps(fit_records,indent=2),encoding='utf-8')
        (OUT/'split_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
        (OUT/'predictions.json').write_text(json.dumps(predictions),encoding='utf-8')

    start=time.perf_counter()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        for seed in range(start_seed, start_seed + repeats):
            split=mod.standardize_split(mod.make_bearing_split(5000+seed))
            clean,l,c,clean_val=mod.tune_clean_svm(split.x_train,split.y_train,split.x_val,split.y_val,np.random.default_rng(seed+9001))
            clean_test=mod.evaluate_method_on_test(split,clean,l,'Clean-RBF',None)
            rows.append({'seed':seed,'method':'Clean-RBF',**clean_test,'candidate_count':0,'rho':0,
                         'lengthscale':l,'C':c,'final_fit_status':int(clean.fit_status_)})
            x,y,xv,yv=split.x_train,split.y_train,split.x_val,split.y_val
            kclean=mod.clean_rbf_kernel(x,x,l)
            u=mod.uncertainty_from_scores(clean.decision_function(kclean))
            cf=.25+.75*u
            rms=float(np.sqrt(np.mean(cf*cf)))
            mutable=np.flatnonzero(split.knowledge_budget>0)
            immutable=np.flatnonzero(split.knowledge_budget==0)
            assert mutable.size==28 and immutable.tolist()==[24,25]
            perm=np.random.default_rng(91000+seed).permutation(mutable)
            shuffled=[g.copy() for g in split.groups]
            offset=0
            for group_id in [0,1,2,4]:
                n=len(shuffled[group_id]);shuffled[group_id]=perm[offset:offset+n];offset+=n
            assert offset==28 and shuffled[3].tolist()==[24,25]
            meta={'seed':seed,'data_seed':5000+seed,'group_shuffle_seed':91000+seed,
                  'train_hash':digest(x),'val_hash':digest(xv),'test_hash':digest(split.x_test),
                  'labels_train_hash':digest(y),'lengthscale':l,'C':c,'sample_factor_rms':rms,
                  'original_groups':[g.tolist() for g in split.groups],
                  'shuffled_groups':[g.tolist() for g in shuffled],
                  'original_budget':split.knowledge_budget.tolist()}
            metadata.append(meta)
            for method in METHODS:
                groups=shuffled if method=='Shuffled-perturbable-groups' else split.groups
                budget=(split.knowledge_budget>0).astype(float) if method=='Unit-budgets' else split.knowledge_budget.copy()
                factors=np.full(len(x),rms) if method=='RMS-constant' else cf
                alphas=mod.candidate_alphas(len(groups),np.random.default_rng(seed+9001))
                assert len(alphas)==13
                best=None
                count=0
                covariance_hashes=set()
                for rho in [1.,2.,4.]:
                    for alpha in alphas:
                        count+=1
                        scale=mod.group_scale_vector(x.shape[1],groups,alpha,budget)
                        var=(rho*factors[:,None]*scale[None,:])**2
                        variance_sum=float(var.sum())
                        covariance_hash=digest(var)
                        covariance_hashes.add(covariance_hash)
                        if method=='RMS-constant':
                            original_sum=float(((rho*cf[:,None]*scale[None,:])**2).sum())
                            assert abs(variance_sum-original_sum)<=1e-8*(1+original_sum)
                        ktr=make_kernel(x,var,l)
                        kval=mod.expected_rbf_kernel(xv,x,np.zeros_like(xv),var,l)
                        model=fit_kernel(ktr,y,c,seed,method,'candidate',count)
                        met=mod.classification_metrics(model,kval,yv)
                        penalty=.0002*float(var.mean())
                        score=met['balanced_accuracy']+.25*met['macro_f1']-penalty
                        candidate_records.append({'seed':seed,'method':method,'candidate_id':count,'rho':rho,
                            'alpha':json.dumps(alpha.tolist()),'validation_score':score,'variance_sum':variance_sum,
                            'variance_mean':float(var.mean()),'covariance_sha256':covariance_hash,'fit_status':int(model.fit_status_),**met})
                        if best is None or score>best['score']:
                            best={'score':score,'rho':rho,'alpha':alpha.copy(),'variance':var.copy(),'candidate_id':count,'selected_validation':met.copy()}
                assert count==39 and len(covariance_hashes)==34
                var=best['variance']
                final=fit_kernel(make_kernel(x,var,l),y,c,seed,method,'final',best['candidate_id'])
                ktest=mod.expected_rbf_kernel(split.x_test,x,np.zeros_like(split.x_test),var,l)
                test=mod.classification_metrics(final,ktest,split.y_test)
                kval=mod.expected_rbf_kernel(xv,x,np.zeros_like(xv),var,l)
                final_val=mod.classification_metrics(final,kval,yv)
                row={'seed':seed,'method':method,**test,'candidate_count':count,'rho':best['rho'],
                     'unique_covariance_count':len(covariance_hashes),
                     'lengthscale':l,'C':c,'alpha':json.dumps(best['alpha'].tolist()),
                     'selected_candidate_id':best['candidate_id'],'selected_validation_score':best['score'],
                     'final_validation_balanced_accuracy':final_val['balanced_accuracy'],
                     'final_validation_macro_f1':final_val['macro_f1'],'final_validation_auc':final_val['auc'],
                     'selected_variance_sum':float(var.sum()),'final_fit_status':int(final.fit_status_)}
                rows.append(row)
                predictions.append({'seed':seed,'method':method,'y_test':split.y_test.tolist(),
                                    'predicted_test':final.predict(ktest).tolist(),'decision_scores_test':final.decision_function(ktest).tolist()})
                print(json.dumps({'seed':seed,'method':method,'bacc':test['balanced_accuracy'],'f1':test['macro_f1'],'auc':test['auc'],'rho':best['rho'],'alpha':best['alpha'].tolist()}),flush=True)
            flush()

        warning_records=[{'category':w.category.__name__,'message':str(w.message),'filename':str(w.filename),'line':w.lineno} for w in caught]

    df=pd.DataFrame(rows)
    summary=df.groupby('method',sort=False).agg(**{f'{k}_{stat}':(k,stat) for k in metrics for stat in ['mean','std']}).reset_index()
    summary.to_csv(OUT/'results_summary.csv',index=False)
    paired=[]
    for baseline in ['Clean-RBF','Shuffled-perturbable-groups','Unit-budgets','RMS-constant']:
        for metric in metrics:
            piv=df.pivot(index='seed',columns='method',values=metric)
            d=piv['Full']-piv[baseline]
            n=len(d);half=float(t.ppf(.975,n-1)*d.std(ddof=1)/np.sqrt(n)) if n > 1 else float("nan")
            paired.append({'proposed':'Full','baseline':baseline,'metric':metric,'mean_difference':float(d.mean()),
                           'ci_low':float(d.mean()-half),'ci_high':float(d.mean()+half),'n':n})
    pd.DataFrame(paired).to_csv(OUT/'paired_ci.csv',index=False)
    maxdelta=None
    if reference_csv:
        old=pd.read_csv(reference_csv)
        old=old[(old.dataset=='Bearing diagnosis') & (old.method=='BiPIN-EK')].set_index('seed')
        new=df[df.method=='Full'].set_index('seed')
        maxdelta=max(float(np.max(np.abs(old.loc[new.index,k]-new[k]))) for k in metrics)
        assert maxdelta<1e-12,maxdelta
    raw_check={}
    for method in METHODS:
        sub=df[df.method==method]
        assert len(sub)==repeats and set(sub.candidate_count)=={39}
        raw_check[method]={'n':len(sub),'candidates':39,'unique_covariances_per_seed':sub.unique_covariance_count.astype(int).tolist(),'final_converged':int((sub.final_fit_status==0).sum())}
    audit={'elapsed_seconds':time.perf_counter()-start,'python':sys.version,'platform':platform.platform(),
           'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
           'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'versions':{m.__name__:m.__version__ for m in [np,pd,scipy,sklearn,matplotlib]},
           'candidate_fit_count':sum(r['stage']=='candidate' for r in fit_records),
           'final_fit_count':sum(r['stage']=='final' for r in fit_records),
           'nonconverged_fits':sum(r['fit_status']!=0 for r in fit_records),
           'warnings':warning_records,'full_vs_previous_max_delta':maxdelta,'method_checks':raw_check,
           'scope':'Generated bearing-feature shift only; the published protocol uses ten generator repetitions. Paired CIs are marginal Student-t intervals; no multiplicity correction. Shuffle chosen once by stated seed, not selected on validation/test.'}
    (OUT/'run_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print('SUMMARY\n'+summary.to_string(index=False),flush=True)
    print('PAIRED\n'+pd.DataFrame(paired).to_string(index=False),flush=True)
    print('AUDIT '+json.dumps(audit,ensure_ascii=False),flush=True)
