from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.signal import hilbert, welch
from scipy.stats import kurtosis, skew, t
from sklearn.datasets import load_breast_cancer, load_digits, load_wine
from sklearn.metrics import (
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

EPS = 1e-12


@dataclass
class DatasetSplit:
    name: str
    x_train: np.ndarray
    y_train: np.ndarray
    x_val: np.ndarray
    y_val: np.ndarray
    x_test: np.ndarray
    y_test: np.ndarray
    groups: List[np.ndarray]
    knowledge_budget: np.ndarray
    feature_names: List[str]
    group_names: List[str]


def stable_softmax(scores: np.ndarray) -> np.ndarray:
    scores = np.asarray(scores)
    if scores.ndim == 1:
        p1 = 1.0 / (1.0 + np.exp(-np.clip(scores, -40, 40)))
        return np.column_stack([1.0 - p1, p1])
    shifted = scores - scores.max(axis=1, keepdims=True)
    exp_scores = np.exp(np.clip(shifted, -40, 40))
    return exp_scores / np.maximum(exp_scores.sum(axis=1, keepdims=True), EPS)


def classification_metrics(model: SVC, kernel: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    pred = model.predict(kernel)
    scores = model.decision_function(kernel)
    classes = model.classes_
    if len(classes) == 2:
        auc = roc_auc_score(y, scores)
    else:
        probs = stable_softmax(scores)
        y_bin = np.zeros((len(y), len(classes)), dtype=float)
        class_to_idx = {c: i for i, c in enumerate(classes)}
        for i, label in enumerate(y):
            y_bin[i, class_to_idx[label]] = 1.0
        auc = roc_auc_score(y_bin, probs, average="macro", multi_class="ovr")
    return {
        "balanced_accuracy": balanced_accuracy_score(y, pred),
        "macro_f1": f1_score(y, pred, average="macro"),
        "auc": auc,
    }


def clean_rbf_kernel(xa: np.ndarray, xb: np.ndarray, lengthscale: float) -> np.ndarray:
    aa = np.sum(xa * xa, axis=1)[:, None]
    bb = np.sum(xb * xb, axis=1)[None, :]
    d2 = np.maximum(aa + bb - 2.0 * xa @ xb.T, 0.0)
    return np.exp(-d2 / (2.0 * lengthscale * lengthscale))


def expected_rbf_kernel(
    xa: np.ndarray,
    xb: np.ndarray,
    var_a: np.ndarray,
    var_b: np.ndarray,
    lengthscale: float,
    chunk_size: int = 256,
) -> np.ndarray:
    """Expected RBF kernel for diagonal Gaussian covariances."""
    n_a, p = xa.shape
    n_b = xb.shape[0]
    out = np.empty((n_a, n_b), dtype=np.float64)
    l2 = lengthscale * lengthscale
    # Normalize in log space. A floor on diag_a * diag_b changes the kernel
    # and can destroy unit diagonal / positive semidefiniteness at large noise.
    log_diag_a = -0.5 * np.sum(np.log1p(2.0 * var_a / l2), axis=1)
    log_diag_b = -0.5 * np.sum(np.log1p(2.0 * var_b / l2), axis=1)
    for start in range(0, n_a, chunk_size):
        end = min(start + chunk_size, n_a)
        d = xa[start:end, None, :] - xb[None, :, :]
        s = var_a[start:end, None, :] + var_b[None, :, :]
        denom = l2 + s
        log_factor = -0.5 * np.sum(np.log1p(s / l2), axis=2)
        exponent = -0.5 * np.sum((d * d) / denom, axis=2)
        log_normalized = (log_factor + exponent
                          - 0.5 * log_diag_a[start:end, None]
                          - 0.5 * log_diag_b[None, :])
        out[start:end] = np.exp(log_normalized)
    return out


def uncertainty_from_scores(scores: np.ndarray) -> np.ndarray:
    scores = np.asarray(scores)
    if scores.ndim == 1:
        margin = np.abs(scores)
    else:
        sorted_scores = np.sort(scores, axis=1)
        margin = sorted_scores[:, -1] - sorted_scores[:, -2]
    scale = np.median(margin) + EPS
    return np.exp(-margin / scale)


def median_lengthscale(x: np.ndarray, rng: np.random.Generator, max_points: int = 500) -> float:
    if len(x) > max_points:
        idx = rng.choice(len(x), size=max_points, replace=False)
        z = x[idx]
    else:
        z = x
    aa = np.sum(z * z, axis=1)[:, None]
    d2 = np.maximum(aa + aa.T - 2.0 * z @ z.T, 0.0)
    vals = d2[np.triu_indices_from(d2, k=1)]
    med = np.median(vals[vals > 0])
    return float(np.sqrt(max(med, 1e-6) / 2.0))


def tune_clean_svm(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    rng: np.random.Generator,
) -> Tuple[SVC, float, float, Dict[str, float]]:
    base_l = median_lengthscale(x_train, rng)
    lengthscales = [0.65 * base_l, base_l, 1.5 * base_l]
    cs = [0.5, 2.0, 8.0]
    best = None
    for l in lengthscales:
        ktr = clean_rbf_kernel(x_train, x_train, l)
        kval = clean_rbf_kernel(x_val, x_train, l)
        for c in cs:
            model = SVC(C=c, kernel="precomputed", class_weight="balanced", max_iter=300, tol=5e-2, cache_size=512, shrinking=False)
            model.fit(ktr, y_train)
            met = classification_metrics(model, kval, y_val)
            score = met["balanced_accuracy"] + 0.25 * met["macro_f1"]
            if best is None or score > best[0]:
                best = (score, model, l, c, met)
    assert best is not None
    # Refit the selected clean model to a tighter numerical tolerance so that
    # the reported test metrics do not inherit the coarse search solver.
    _, _, best_l, best_c, best_met = best
    ktr = clean_rbf_kernel(x_train, x_train, best_l)
    final_model = SVC(
        C=best_c, kernel="precomputed", class_weight="balanced",
        max_iter=5000, tol=1e-4, cache_size=512, shrinking=False,
    )
    final_model.fit(ktr, y_train)
    return final_model, best_l, best_c, best_met


def group_scale_vector(
    p: int,
    groups: Sequence[np.ndarray],
    alpha: np.ndarray,
    budget: np.ndarray,
) -> np.ndarray:
    scale = np.zeros(p, dtype=float)
    for g, idx in enumerate(groups):
        scale[idx] = alpha[g]
    return scale * budget


def candidate_alphas(n_groups: int, rng: np.random.Generator) -> List[np.ndarray]:
    candidates: List[np.ndarray] = [np.zeros(n_groups), np.full(n_groups, 0.25), np.full(n_groups, 0.65)]
    for g in range(n_groups):
        one = np.zeros(n_groups)
        one[g] = 1.0
        candidates.append(one)
        focused = np.full(n_groups, 0.10)
        focused[g] = 0.90
        candidates.append(focused)
    unique: Dict[Tuple[float, ...], np.ndarray] = {}
    for a in candidates:
        unique[tuple(np.round(a, 4))] = a
    return list(unique.values())

def fit_expected_kernel_method(
    split: DatasetSplit,
    clean_model: SVC,
    lengthscale: float,
    c_value: float,
    method: str,
    rng: np.random.Generator,
) -> Tuple[SVC, Dict[str, float], Dict[str, np.ndarray | float]]:
    xtr, ytr, xv, yv = split.x_train, split.y_train, split.x_val, split.y_val
    scores = clean_model.decision_function(clean_rbf_kernel(xtr, xtr, lengthscale))
    uncertainty = uncertainty_from_scores(scores)
    p = xtr.shape[1]
    groups = split.groups
    budget = split.knowledge_budget.copy()
    if method == "Adaptive-no-knowledge":
        groups = [np.arange(p)]
        budget = np.ones(p)
    elif method == "Fixed-Gaussian":
        groups = [np.arange(p)]
        budget = np.ones(p)
    alphas = candidate_alphas(len(groups), rng)
    if method == "Fixed-Gaussian":
        alphas = [np.ones(len(groups))]
    rhos = [1.0, 2.0, 4.0]
    best = None
    for rho in rhos:
        for alpha in alphas:
            feat_scale = group_scale_vector(p, groups, alpha, budget)
            if method == "Fixed-Gaussian":
                sample_factor = np.ones(len(xtr))
            else:
                sample_factor = 0.25 + 0.75 * uncertainty
            std_train = rho * sample_factor[:, None] * feat_scale[None, :]
            var_train = std_train * std_train
            var_val = np.zeros_like(xv)
            ktr = expected_rbf_kernel(xtr, xtr, var_train, var_train, lengthscale)
            # Numerical symmetry and jitter for QP stability.
            ktr = 0.5 * (ktr + ktr.T)
            ktr.flat[:: len(ktr) + 1] += 1e-9
            kval = expected_rbf_kernel(xv, xtr, var_val, var_train, lengthscale)
            model = SVC(C=c_value, kernel="precomputed", class_weight="balanced", max_iter=300, tol=5e-2, cache_size=512, shrinking=False)
            model.fit(ktr, ytr)
            met = classification_metrics(model, kval, yv)
            mag_pen = float(np.mean(var_train))
            score = met["balanced_accuracy"] + 0.25 * met["macro_f1"] - 0.0002 * mag_pen
            if best is None or score > best[0]:
                best = (score, model, met, rho, alpha.copy(), var_train.copy(), feat_scale.copy(), uncertainty.copy())
    assert best is not None
    # Refit the selected expected-kernel SVM at a tight tolerance. The outer
    # search remains deliberately coarse, but all reported test metrics use
    # this final converged inner model.
    _, _, best_met, best_rho, best_alpha, best_var_train, best_feat_scale, best_uncertainty = best
    ktr = expected_rbf_kernel(xtr, xtr, best_var_train, best_var_train, lengthscale)
    ktr = 0.5 * (ktr + ktr.T)
    ktr.flat[:: len(ktr) + 1] += 1e-9
    final_model = SVC(
        C=c_value, kernel="precomputed", class_weight="balanced",
        max_iter=5000, tol=1e-4, cache_size=512, shrinking=False,
    )
    final_model.fit(ktr, ytr)
    info = {
        "rho": float(best_rho),
        "alpha": best_alpha,
        "var_train": best_var_train,
        "feature_scale": best_feat_scale,
        "uncertainty": best_uncertainty,
    }
    return final_model, best_met, info


def evaluate_method_on_test(
    split: DatasetSplit,
    model: SVC,
    lengthscale: float,
    method: str,
    info: Dict[str, np.ndarray | float] | None,
) -> Dict[str, float]:
    if method in {"Clean-RBF", "Linear-SVM"}:
        ktest = clean_rbf_kernel(split.x_test, split.x_train, lengthscale)
    else:
        assert info is not None
        var_train = np.asarray(info["var_train"])
        var_test = np.zeros_like(split.x_test)
        ktest = expected_rbf_kernel(split.x_test, split.x_train, var_test, var_train, lengthscale)
    return classification_metrics(model, ktest, split.y_test)


def make_synthetic_split(seed: int) -> DatasetSplit:
    rng = np.random.default_rng(seed)
    p = 20
    def block(n: int, condition: int) -> Tuple[np.ndarray, np.ndarray]:
        y = rng.integers(0, 2, size=n)
        ys = 2 * y - 1
        x = rng.normal(size=(n, p))
        x[:, :4] += ys[:, None] * np.array([1.0, -0.8, 0.7, -0.6])[None, :]
        if condition == 0:
            x[:, 4:8] += ys[:, None] * 1.15
        else:
            x[:, 4:8] -= ys[:, None] * 0.35
        # nonlinear stable signal
        x[:, 8] += ys * 0.65 * np.sign(x[:, 0] * x[:, 1] + 0.1)
        # condition artifact independent of class in target domain
        x[:, 12:16] += condition * 0.8
        return x, y
    xtr, ytr = block(360, 0)
    xv, yv = block(150, 1)
    xt, yt = block(300, 1)
    groups = [np.arange(0, 4), np.arange(4, 8), np.arange(8, 12), np.arange(12, 20)]
    budget = np.ones(p)
    budget[0:4] = 0.35
    budget[4:8] = 1.0
    budget[8:12] = 0.55
    budget[12:20] = 0.75
    names = [f"x{j+1}" for j in range(p)]
    return DatasetSplit("Synthetic shift", xtr, ytr, xv, yv, xt, yt, groups, budget, names,
                        ["stable", "spurious", "nonlinear", "nuisance"])


def stratified_public_split(name: str, seed: int) -> DatasetSplit:
    if name == "Breast cancer":
        data = load_breast_cancer()
    elif name == "Wine":
        data = load_wine()
    elif name == "Digits":
        data = load_digits()
    else:
        raise ValueError(name)
    x = np.asarray(data.data, dtype=float)
    y = np.asarray(data.target)
    if name == "Digits":
        rng = np.random.default_rng(seed)
        keep = np.concatenate([rng.choice(np.flatnonzero(y == c), size=min(70, np.sum(y == c)), replace=False) for c in np.unique(y)])
        x, y = x[keep], y[keep]
    x_dev, x_test, y_dev, y_test = train_test_split(
        x, y, test_size=0.25, stratify=y, random_state=seed
    )
    x_train, x_val, y_train, y_val = train_test_split(
        x_dev, y_dev, test_size=0.25, stratify=y_dev, random_state=seed + 101
    )
    p = x.shape[1]
    # Generic semantic groups: low-, medium-, and high-index feature blocks.
    edges = np.linspace(0, p, 4, dtype=int)
    groups = [np.arange(edges[i], edges[i + 1]) for i in range(3) if edges[i] < edges[i + 1]]
    budget = np.ones(p)
    return DatasetSplit(name, x_train, y_train, x_val, y_val, x_test, y_test, groups, budget,
                        list(getattr(data, "feature_names", [f"x{j+1}" for j in range(p)])),
                        [f"group {i+1}" for i in range(len(groups))])


def impulse_train(t: np.ndarray, freq: float, resonance: float, decay: float, phase: float) -> np.ndarray:
    period = 1.0 / freq
    events = np.arange(phase, t[-1] + period, period)
    out = np.zeros_like(t)
    for event in events:
        dt = t - event
        mask = dt >= 0
        out[mask] += np.exp(-decay * dt[mask]) * np.sin(2 * np.pi * resonance * dt[mask])
    return out


def simulate_bearing_signal(
    cls: int,
    load: int,
    rng: np.random.Generator,
    n_samples: int = 2048,
    fs: float = 12000.0,
) -> Tuple[np.ndarray, float]:
    rpm = [1797, 1772, 1750, 1730][load] + rng.normal(0, 2.0)
    shaft = rpm / 60.0
    t = np.arange(n_samples) / fs
    amp = 0.62 + 0.025 * load + rng.uniform(-0.04, 0.04)
    signal = amp * np.sin(2 * np.pi * shaft * t + rng.uniform(0, 2 * np.pi))
    signal += 0.18 * np.sin(2 * np.pi * 2 * shaft * t + rng.uniform(0, 2 * np.pi))
    signal += rng.normal(0, 0.12 + 0.006 * load, size=n_samples)
    resonance = 2800 + 20 * load + rng.normal(0, 35)
    if cls == 1:  # inner race
        signal += (0.70 + 0.025 * load) * impulse_train(t, 5.4 * shaft, resonance, 850, rng.uniform(0, 1/(5.4*shaft)))
    elif cls == 2:  # ball
        carrier = impulse_train(t, 2.35 * shaft, resonance * 0.92, 720, rng.uniform(0, 1/(2.35*shaft)))
        signal += (0.62 + 0.020 * load) * carrier * (1 + 0.45 * np.sin(2 * np.pi * shaft * t))
    elif cls == 3:  # outer race
        signal += (0.74 + 0.025 * load) * impulse_train(t, 3.58 * shaft, resonance * 1.05, 920, rng.uniform(0, 1/(3.58*shaft)))
    # Load-dependent sensor transfer artifact; present across all classes.
    signal += 0.025 * load * np.sin(2 * np.pi * (420 + 30 * load) * t + rng.uniform(0, 2*np.pi))
    return signal, rpm


def extract_vibration_features(x: np.ndarray, rpm: float, fs: float = 12000.0) -> Tuple[np.ndarray, List[str], List[int]]:
    centered = x - np.mean(x)
    absx = np.abs(centered)
    rms = np.sqrt(np.mean(centered ** 2))
    std = np.std(centered)
    peak = np.max(absx)
    mean_abs = np.mean(absx) + EPS
    root_abs = np.mean(np.sqrt(absx + EPS)) ** 2 + EPS
    time_features = [
        np.mean(x), std, rms, skew(centered), kurtosis(centered, fisher=False), peak,
        peak / (rms + EPS), rms / mean_abs, peak / mean_abs, peak / root_abs,
    ]
    time_names = ["mean", "std", "rms", "skewness", "kurtosis", "peak", "crest factor",
                  "shape factor", "impulse factor", "clearance factor"]
    f, psd = welch(centered, fs=fs, nperseg=512, noverlap=256)
    psd = np.maximum(psd, EPS)
    pnorm = psd / np.sum(psd)
    centroid = np.sum(f * pnorm)
    bandwidth = np.sqrt(np.sum(((f - centroid) ** 2) * pnorm))
    entropy = -np.sum(pnorm * np.log(pnorm)) / np.log(len(pnorm))
    bands = [(0, 300), (300, 700), (700, 1200), (1200, 2000), (2000, 3000), (3000, 4500), (4500, 6000)]
    band_energy = []
    for lo, hi in bands:
        mask = (f >= lo) & (f < hi)
        band_energy.append(np.log10(np.sum(psd[mask]) + EPS))
    freq_features = [centroid, bandwidth, entropy] + band_energy
    freq_names = ["spectral centroid", "spectral bandwidth", "spectral entropy"] + [f"band {lo}-{hi} Hz" for lo, hi in bands]
    env = np.abs(hilbert(centered))
    fe, pe = welch(env - env.mean(), fs=fs, nperseg=1024, noverlap=512)
    shaft = rpm / 60.0
    characteristic = [shaft, 2.35 * shaft, 3.58 * shaft, 5.4 * shaft]
    env_features = []
    for cf in characteristic:
        mask = np.abs(fe - cf) <= max(3.0, 0.08 * cf)
        env_features.append(np.log10(np.sum(pe[mask]) + EPS))
    env_features += [rpm, shaft]
    env_names = ["shaft envelope", "ball envelope", "outer-race envelope", "inner-race envelope", "rpm", "shaft frequency"]
    vals = np.asarray(time_features + freq_features + env_features, dtype=float)
    groups = [0] * len(time_features) + [1] * len(freq_features) + [2] * 4 + [3] * 2
    return vals, time_names + freq_names + env_names, groups


def make_bearing_split(seed: int, per_class_load: int = 45) -> DatasetSplit:
    """Fast controlled rotating-machinery feature benchmark.

    The feature means follow common vibration-diagnostic signatures (impulsiveness,
    band energy, and envelope peaks), while four condition-proxy channels change
    their label association between source and target loads.
    """
    rng = np.random.default_rng(seed)
    time_names = ["mean", "std", "rms", "skewness", "kurtosis", "peak", "crest factor",
                  "shape factor", "impulse factor", "clearance factor"]
    freq_names = ["spectral centroid", "spectral bandwidth", "spectral entropy"] + [
        "band 0-300 Hz", "band 300-700 Hz", "band 700-1200 Hz", "band 1200-2000 Hz",
        "band 2000-3000 Hz", "band 3000-4500 Hz", "band 4500-6000 Hz"
    ]
    env_names = ["shaft envelope", "ball envelope", "outer-race envelope", "inner-race envelope"]
    op_names = ["rpm", "shaft frequency"]
    proxy_names = [f"condition proxy {k+1}" for k in range(4)]
    feature_names = time_names + freq_names + env_names + op_names + proxy_names
    p = len(feature_names)
    groups = [
        np.arange(0, 10), np.arange(10, 20), np.arange(20, 24),
        np.arange(24, 26), np.arange(26, 30)
    ]
    group_names = ["time-domain", "spectral", "envelope", "operating", "condition proxies"]
    budget = np.ones(p)
    budget[groups[0]] = 0.55
    budget[groups[1]] = 0.75
    budget[groups[2]] = 0.65
    budget[groups[3]] = 0.0
    budget[groups[4]] = 1.35

    # Stable class signatures in time, frequency, and envelope groups.
    class_mu = np.zeros((4, 24))
    class_mu[1, [1,2,4,5,6,8,9]] = [0.7,0.8,1.4,1.0,0.8,0.9,0.8]
    class_mu[1, 10:20] = [0.25,0.35,-0.10,0.05,0.15,0.30,0.65,1.10,0.75,0.35]
    class_mu[1, 20:24] = [0.10,0.15,0.20,1.65]
    class_mu[2, [1,2,4,5,6,8,9]] = [0.55,0.60,0.95,0.75,0.65,0.70,0.65]
    class_mu[2, 10:20] = [0.15,0.25,-0.05,0.05,0.35,0.75,0.80,0.55,0.30,0.20]
    class_mu[2, 20:24] = [0.15,1.55,0.20,0.25]
    class_mu[3, [1,2,4,5,6,8,9]] = [0.65,0.72,1.20,0.92,0.72,0.82,0.76]
    class_mu[3, 10:20] = [0.18,0.30,-0.08,0.25,0.70,0.95,0.55,0.35,0.22,0.18]
    class_mu[3, 20:24] = [0.12,0.20,1.60,0.20]

    rows: List[np.ndarray] = []
    labels: List[int] = []
    loads: List[int] = []
    examples: Dict[Tuple[int, int], np.ndarray] = {}
    for load in range(4):
        rpm0 = [1797, 1772, 1750, 1730][load]
        load_shift = np.zeros(24)
        load_shift[0:10] = load * np.array([0.00,0.08,0.10,0.00,0.05,0.08,0.02,0.03,0.03,0.02])
        load_shift[10:20] = load * np.array([0.08,0.06,0.03,0.10,0.08,0.06,0.04,0.03,0.02,0.02])
        load_shift[20:24] = load * np.array([0.04,0.03,0.03,0.03])
        for cls in range(4):
            if (load, cls) not in examples:
                examples[(load, cls)] = simulate_bearing_signal(cls, load, rng)[0]
            for _ in range(per_class_load):
                common = rng.normal(0, 0.34, size=24)
                # Mild correlations within feature groups.
                common[1:10] += rng.normal(0, 0.16)
                common[10:20] += rng.normal(0, 0.14)
                common[20:24] += rng.normal(0, 0.12)
                physical = class_mu[cls] + load_shift + common
                rpm = rpm0 + rng.normal(0, 2.5)
                operating = np.array([rpm, rpm / 60.0])
                # Source-condition proxy channels are strongly label-associated;
                # the target conditions use a shifted mapping.
                mapping = cls if load <= 1 else (cls + 1) % 4
                artifact = rng.normal(0, 0.42, size=4)
                artifact[mapping] += 2.45
                rows.append(np.concatenate([physical, operating, artifact]))
                labels.append(cls)
                loads.append(load)
    x = np.asarray(rows, dtype=float)
    y = np.asarray(labels)
    loads_arr = np.asarray(loads)
    train_mask = loads_arr <= 1
    val_mask = loads_arr == 2
    test_mask = loads_arr == 3
    split = DatasetSplit(
        "Bearing diagnosis", x[train_mask], y[train_mask], x[val_mask], y[val_mask],
        x[test_mask], y[test_mask], groups, budget, feature_names, group_names
    )
    split.examples = examples  # type: ignore[attr-defined]
    return split

def standardize_split(split: DatasetSplit) -> DatasetSplit:
    scaler = StandardScaler().fit(split.x_train)
    return DatasetSplit(
        split.name,
        scaler.transform(split.x_train), split.y_train,
        scaler.transform(split.x_val), split.y_val,
        scaler.transform(split.x_test), split.y_test,
        split.groups, split.knowledge_budget, split.feature_names, split.group_names,
    )


def fit_and_evaluate(split: DatasetSplit, seed: int) -> Tuple[List[Dict[str, object]], Dict[str, object]]:
    rng = np.random.default_rng(seed + 9001)
    split_s = standardize_split(split)
    clean_model, lengthscale, c_value, clean_val = tune_clean_svm(
        split_s.x_train, split_s.y_train, split_s.x_val, split_s.y_val, rng
    )
    rows: List[Dict[str, object]] = []
    clean_test = evaluate_method_on_test(split_s, clean_model, lengthscale, "Clean-RBF", None)
    rows.append({"dataset": split.name, "seed": seed, "method": "Clean-RBF", **clean_test,
                 "rho": 0.0, "lengthscale": lengthscale, "C": c_value, "train_time": np.nan})
    method_info = {}
    for method in ["Fixed-Gaussian", "Adaptive-no-knowledge", "BiPIN-EK"]:
        t0 = time.perf_counter()
        model, val_met, info = fit_expected_kernel_method(
            split_s, clean_model, lengthscale, c_value, method, rng
        )
        elapsed = time.perf_counter() - t0
        test_met = evaluate_method_on_test(split_s, model, lengthscale, method, info)
        rows.append({"dataset": split.name, "seed": seed, "method": method, **test_met,
                     "rho": info["rho"], "lengthscale": lengthscale, "C": c_value, "train_time": elapsed})
        method_info[method] = {"model": model, "info": info, "val": val_met, "split": split_s}
    return rows, {"clean_model": clean_model, "lengthscale": lengthscale, "C": c_value,
                  "clean_val": clean_val, "methods": method_info, "split": split_s}


def paired_ci(df: pd.DataFrame, metric: str, proposed: str = "BiPIN-EK", baseline: str = "Clean-RBF") -> pd.DataFrame:
    records = []
    for dataset, grp in df.groupby("dataset"):
        piv = grp.pivot(index="seed", columns="method", values=metric).dropna()
        diff = piv[proposed] - piv[baseline]
        n = len(diff)
        mean = diff.mean()
        sd = diff.std(ddof=1) if n > 1 else 0.0
        half = t.ppf(0.975, df=n - 1) * sd / math.sqrt(max(n, 1)) if n > 1 else 0.0
        records.append({"dataset": dataset, "metric": metric, "mean_difference": mean,
                        "ci_low": mean - half, "ci_high": mean + half, "n": n})
    return pd.DataFrame(records)


def plot_results(summary: pd.DataFrame, raw: pd.DataFrame, example_info: Dict[str, object], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    methods = ["Clean-RBF", "Fixed-Gaussian", "Adaptive-no-knowledge", "BiPIN-EK"]
    datasets = list(summary["dataset"].drop_duplicates())

    # Performance figure: separate panels are assembled in LaTeX, but save one compact two-panel figure.
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.15))
    width = 0.18
    x = np.arange(len(datasets))
    for j, method in enumerate(methods):
        part = summary[summary.method == method].set_index("dataset").reindex(datasets)
        axes[0].bar(x + (j - 1.5) * width, part["balanced_accuracy_mean"], width,
                    yerr=part["balanced_accuracy_std"], capsize=2, label=method)
        axes[1].bar(x + (j - 1.5) * width, part["macro_f1_mean"], width,
                    yerr=part["macro_f1_std"], capsize=2, label=method)
    for ax, title, ylabel in [(axes[0], "Balanced accuracy", "Balanced accuracy"), (axes[1], "Macro-F1", "Macro-F1")]:
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.set_xticks(x)
        ax.set_xticklabels(datasets, rotation=22, ha="right")
        ax.set_ylim(0.0, 1.02)
        ax.grid(axis="y", alpha=0.25)
    handles, labels = axes[1].get_legend_handles_labels()
    fig.legend(handles, labels, fontsize=8, frameon=False, loc="upper center", ncol=4,
               bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=(0, 0, 1, 0.91))
    fig.savefig(out_dir / "main_performance.pdf", bbox_inches="tight")
    fig.savefig(out_dir / "main_performance.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    # Learned group scales for bearing case.
    bearing = example_info["methods"]["BiPIN-EK"]  # type: ignore[index]
    split: DatasetSplit = bearing["split"]  # type: ignore[assignment]
    info = bearing["info"]  # type: ignore[assignment]
    feat_scale = np.asarray(info["feature_scale"])
    group_means = [feat_scale[idx].mean() if len(idx) else 0.0 for idx in split.groups]
    fig, ax = plt.subplots(figsize=(5.8, 3.5))
    ax.bar(split.group_names, group_means)
    ax.set_ylabel("Selected perturbation scale")
    ax.tick_params(axis="x", rotation=16)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "group_scales.pdf", bbox_inches="tight")
    fig.savefig(out_dir / "group_scales.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    # Noise magnitude vs clean margin/uncertainty.
    uncertainty = np.asarray(info["uncertainty"])
    var_train = np.asarray(info["var_train"])
    magnitude = np.sqrt(var_train.sum(axis=1))
    fig, ax = plt.subplots(figsize=(5.8, 3.5))
    ax.scatter(uncertainty, magnitude, s=14, alpha=0.55)
    coef = np.polyfit(uncertainty, magnitude, deg=1)
    xx = np.linspace(uncertainty.min(), uncertainty.max(), 100)
    ax.plot(xx, coef[0] * xx + coef[1], linewidth=1.5)
    ax.set_xlabel("Clean-model uncertainty")
    ax.set_ylabel("Perturbation standard-deviation norm")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "margin_noise_relation.pdf", bbox_inches="tight")
    fig.savefig(out_dir / "margin_noise_relation.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    # Confusion matrices for bearing test, clean and proposed.
    clean_model: SVC = example_info["clean_model"]  # type: ignore[assignment]
    l = float(example_info["lengthscale"])
    clean_pred = clean_model.predict(clean_rbf_kernel(split.x_test, split.x_train, l))
    prop_model: SVC = bearing["model"]  # type: ignore[assignment]
    prop_pred = prop_model.predict(expected_rbf_kernel(split.x_test, split.x_train,
                                                        np.zeros_like(split.x_test), var_train, l))
    cm_clean = confusion_matrix(split.y_test, clean_pred, normalize="true")
    cm_prop = confusion_matrix(split.y_test, prop_pred, normalize="true")
    fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.35), constrained_layout=True)
    for ax, cm, title in zip(axes, [cm_clean, cm_prop], ["Clean RBF-SVM", "BiPIN-EK"]):
        im = ax.imshow(cm, vmin=0, vmax=1)
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                text_color = "white" if cm[i, j] < 0.22 else "black"
                ax.text(j, i, f"{cm[i,j]:.2f}", ha="center", va="center", fontsize=8,
                        color=text_color)
        ax.set_title(title)
        ax.set_xlabel("Predicted class")
        ax.set_ylabel("True class")
        ax.set_xticks(range(4), ["N", "IR", "B", "OR"])
        ax.set_yticks(range(4), ["N", "IR", "B", "OR"])
    fig.colorbar(im, ax=axes, shrink=0.82, fraction=0.035, pad=0.03)
    fig.savefig(out_dir / "bearing_confusion.pdf", bbox_inches="tight")
    fig.savefig(out_dir / "bearing_confusion.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    # Sensitivity curve from raw selected rho and performance.
    bearing_raw = raw[raw.dataset == "Bearing diagnosis"]
    fig, ax = plt.subplots(figsize=(5.8, 3.5))
    vals = bearing_raw[bearing_raw.method == "BiPIN-EK"]
    ax.scatter(vals["rho"], vals["balanced_accuracy"], s=35)
    ax.set_xlabel("Selected noise budget $\\rho$")
    ax.set_ylabel("Balanced accuracy")
    ax.set_title("Selected budget and cross-load accuracy")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "rho_sensitivity.pdf", bbox_inches="tight")
    fig.savefig(out_dir / "rho_sensitivity.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
