"""Rebuild paper numeric figures from frozen tables and a deterministic seed-0 fit."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from . import core
from .concept_figure import draw


def rebuild(reference: Path, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(reference / "results_raw.csv")
    summary = pd.read_csv(reference / "results_summary.csv")
    selected = raw[(raw.dataset == "Bearing diagnosis") & (raw.seed == 0)]
    required = {"Clean-RBF", "Fixed-Gaussian", "Adaptive-no-knowledge", "BiPIN-EK"}
    if len(selected) != 4 or selected.method.duplicated().any() or set(selected.method) != required:
        raise ValueError("Figure reconstruction requires exactly four unique bearing seed-0 methods in the reference CSV")
    if not np.isfinite(selected[["balanced_accuracy", "macro_f1", "auc"]].to_numpy(dtype=float)).all():
        raise ValueError("Reference seed-0 metrics must be finite")
    generated = core.make_bearing_split(5000)
    rows, example = core.fit_and_evaluate(generated, seed=0)
    expected = selected.set_index("method")
    actual = pd.DataFrame(rows).set_index("method")
    if not np.isfinite(actual[["balanced_accuracy", "macro_f1", "auc"]].to_numpy(dtype=float)).all():
        raise AssertionError("Regenerated seed-0 metrics must be finite")
    maximum = max(float(np.max(np.abs(expected[k] - actual[k]))) for k in ["balanced_accuracy", "macro_f1", "auc"])
    if maximum > 1e-12:
        raise AssertionError(f"Seed-0 figure fit does not match reference metrics: {maximum}")
    core.plot_results(summary, raw, example, out)
    # This unused diagnostic is not part of the manuscript's figure mapping.
    for extension in ["pdf", "png"]:
        unused = out / f"rho_sensitivity.{extension}"
        if unused.exists():
            unused.unlink()
    # Waveforms are generated only for illustration, not used to extract the
    # feature table. Reuse the exact generator draws already present in the split.
    fig, axes = plt.subplots(2, 2, figsize=(8.4, 4.3), sharex=True)
    class_names = ["Normal", "Inner-race fault", "Ball fault", "Outer-race fault"]
    for label, ax in enumerate(axes.flat):
        signal = generated.examples[(0, label)][:1024]
        time = np.arange(len(signal)) / 12000.0
        ax.plot(time, signal, linewidth=0.7)
        ax.set_title(class_names[label], fontsize=10)
        ax.set_ylabel("Amplitude")
        ax.grid(alpha=0.25)
    for ax in axes[-1]:
        ax.set_xlabel("Time (s)")
    fig.tight_layout()
    fig.savefig(out / "bearing_signals.pdf", bbox_inches="tight")
    fig.savefig(out / "bearing_signals.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    draw(out)
    manifest = {"source": "Frozen main metrics; exact reviewed bearing generator and seed0 model fitting",
                "bearing_data_seed": 5000, "repetition": 0, "max_seed0_metric_delta": maximum,
                "figure_files": ["main_performance.pdf", "group_scales.pdf", "margin_noise_relation.pdf", "bearing_confusion.pdf", "bearing_signals.pdf", "covariance_design.pdf"],
                "waveform_scope": "Illustrative simulator outputs, never classification input; layout may differ from the earlier supplied PDF.",
                "concept_scope": "Input representations only; contours are not observed data, calibrated noise or kernel level sets.",
                "framework_scope": "The manuscript workflow diagram was drawn in LaTeX; its manuscript source is intentionally outside this code-only repository."}
    (out / "figure_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
