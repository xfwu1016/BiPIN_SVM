"""Published experiment orchestration, with non-invasive solver-status logging."""
from pathlib import Path
import hashlib
import inspect
import json
import platform
import sys
import time
import warnings
import numpy as np
import pandas as pd
import scipy
import sklearn
import matplotlib
from sklearn.svm import SVC
from . import core
from .reporting import write_main_tables


class FitAudit:
    def __enter__(self):
        self.rows = []
        self.original = SVC.fit
        audit = self

        def fit(model, *args, **kwargs):
            result = audit.original(model, *args, **kwargs)
            caller = inspect.currentframe().f_back
            local = caller.f_locals
            stage = "final" if local.get("final_model") is model else "candidate"
            audit.rows.append({"caller": caller.f_code.co_name, "method": local.get("method", "Clean-RBF"),
                               "stage": stage, "fit_status": int(model.fit_status_),
                               "n_iter": model.n_iter_.tolist(), "C": float(model.C),
                               "tol": float(model.tol), "max_iter": int(model.max_iter)})
            return result

        SVC.fit = fit
        return self

    def __exit__(self, kind, value, traceback):
        SVC.fit = self.original


def run_main(out: Path, repeats=10, start_seed=0, plots=False):
    if repeats < 1 or start_seed < 0:
        raise ValueError("repeats must be positive and start_seed nonnegative")
    out.mkdir(parents=True, exist_ok=True)
    all_rows = []
    bearing_example = None
    started = time.perf_counter()
    with warnings.catch_warnings(record=True) as caught, FitAudit() as fits:
        warnings.simplefilter("always")
        for seed in range(start_seed, start_seed + repeats):
            # Do not remove the illustrative waveform draws inside the bearing
            # generator: they consume its RNG and are part of the frozen data.
            splits = [core.make_synthetic_split(1000 + seed),
                      core.stratified_public_split("Breast cancer", 2000 + seed),
                      core.stratified_public_split("Wine", 3000 + seed),
                      core.make_bearing_split(5000 + seed)]
            for split in splits:
                print(f"repetition={seed} dataset={split.name}", flush=True)
                rows, info = core.fit_and_evaluate(split, seed)
                all_rows.extend(rows)
                if split.name == "Bearing diagnosis" and seed == 0:
                    bearing_example = info
    raw = pd.DataFrame(all_rows)
    summary = write_main_tables(raw, out)
    if bearing_example is not None:
        model_info = bearing_example["methods"]["BiPIN-EK"]["info"]
        split = bearing_example["methods"]["BiPIN-EK"]["split"]
        metadata = {"rho": float(model_info["rho"]), "alpha": model_info["alpha"].tolist(),
                    "group_names": split.group_names,
                    "group_mean_feature_scale": [float(model_info["feature_scale"][g].mean()) for g in split.groups]}
        (out / "bearing_selected_scales.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        if plots:
            figures = out / "figures"
            figures.mkdir(exist_ok=True)
            core.plot_results(summary, raw, bearing_example, figures)
    audit = {"python": sys.version, "platform": platform.platform(),
             "versions": {m.__name__: m.__version__ for m in [np, pd, scipy, sklearn, matplotlib]},
             "repeats": repeats, "start_seed": start_seed, "elapsed_seconds": time.perf_counter() - started,
             "fit_count": len(fits.rows), "final_fit_count": sum(r["stage"] == "final" for r in fits.rows),
             "nonconverged_fits": sum(r["fit_status"] != 0 for r in fits.rows),
             "warnings": [{"category": w.category.__name__, "message": str(w.message)} for w in caught],
             "core_sha256": hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest(),
             "timing_scope": "Execution log, not a controlled hardware benchmark."}
    (out / "run_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    (out / "fit_records.json").write_text(json.dumps(fits.rows, indent=2), encoding="utf-8")
    return raw, summary, audit


def run_smoke(root: Path, out: Path):
    from .verification import verify_frozen
    frozen = verify_frozen(root)
    raw, _, audit = run_main(out, repeats=1, start_seed=0, plots=False)
    reference = pd.read_csv(root / "results/reference/main/results_raw.csv")
    reference = reference[reference.seed == 0]
    comparison = raw.merge(reference, on=["dataset", "seed", "method"], suffixes=("_new", "_frozen"), validate="one_to_one")
    if len(comparison) != 16:
        raise AssertionError("Smoke run did not cover all 16 seed-0 models")
    deltas = {metric: float(np.max(np.abs(comparison[metric + "_new"] - comparison[metric + "_frozen"])))
              for metric in ["balanced_accuracy", "macro_f1", "auc"]}
    if max(deltas.values()) > 1e-12:
        raise AssertionError(f"Seed-0 metrics differ from frozen values: {deltas}")
    if audit["nonconverged_fits"] or audit["warnings"]:
        raise AssertionError("Inspect solver warnings or fit status in smoke output")
    result = {"status": "PASS", "repetition": 0, "models_checked": 16, "max_metric_deltas": deltas,
              "fit_count": audit["fit_count"], "final_fit_count": audit["final_fit_count"],
              "frozen_verification": frozen["status"],
              "scope": "One exact published repetition, not a rerun of all ten repetitions or the component study."}
    (out / "smoke_report.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result
