"""Lazy imports let frozen-result verification run without scientific packages."""
from pathlib import Path
import argparse
import json
import os

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description="Reproduce the corrected BiPIN-SVM study")
    commands = parser.add_subparsers(dest="command", required=True)
    verify = commands.add_parser("verify", help="Verify frozen CSVs with the Python standard library")
    verify.add_argument("--out", type=Path, default=ROOT / "runs/verification.json")
    main_exp = commands.add_parser("main", help="Four-dataset experiment; defaults to the published ten repetitions")
    main_exp.add_argument("--out", type=Path, default=ROOT / "runs/main")
    main_exp.add_argument("--repeats", type=int, default=10)
    main_exp.add_argument("--start", type=int, default=0)
    main_exp.add_argument("--plots", action="store_true", help="Also render model diagnostics when repetition 0 is present")
    ablation = commands.add_parser("ablation", help="Matched retained bearing component checks")
    ablation.add_argument("--out", type=Path, default=ROOT / "runs/ablation")
    ablation.add_argument("--repeats", type=int, default=10)
    ablation.add_argument("--start", type=int, default=0)
    figures = commands.add_parser("figures", help="Rebuild numeric figures and the conceptual illustration")
    figures.add_argument("--out", type=Path, default=ROOT / "runs/figures")
    figures.add_argument("--reference", type=Path, default=ROOT / "results/reference/main")
    smoke = commands.add_parser("smoke", help="One published repetition on four datasets, kernel checks and frozen-result comparison")
    smoke.add_argument("--out", type=Path, default=ROOT / "runs/smoke")
    aggregate = commands.add_parser("aggregate", help="Recompute main summaries from an experiment CSV")
    aggregate.add_argument("--raw", type=Path, required=True)
    aggregate.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "ablation" and (args.start < 0 or args.repeats < 1 or args.start + args.repeats > 10):
        parser.error("Published ablation comparisons cover repetition seeds 0 through 9; choose a positive subrange within those seeds.")
    if args.command == "verify":
        from .verification import verify_frozen
        result = verify_frozen(ROOT)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))
        return
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLBACKEND", "Agg")
    os.environ.setdefault("MPLCONFIGDIR", str(out / ".mplconfig"))
    if args.command == "main":
        from .pipeline import run_main
        run_main(out, args.repeats, args.start, args.plots)
    elif args.command == "ablation":
        from .ablation import run
        run(out, args.repeats, args.start, ROOT / "results/reference/main/results_raw.csv")
    elif args.command == "figures":
        from .figures import rebuild
        rebuild(args.reference.resolve(), out)
    elif args.command == "smoke":
        from .pipeline import run_smoke
        print(json.dumps(run_smoke(ROOT, out), indent=2))
    elif args.command == "aggregate":
        from .reporting import aggregate_main
        aggregate_main(args.raw.resolve(), out)
