"""BiPIN-SVM reproduction utilities.

This package has no import-time experiment or installation side effects.
"""
