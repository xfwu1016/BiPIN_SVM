"""Illustrative covariance diagram; contours are not measured data or kernel contours."""
from pathlib import Path
import json
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Ellipse, FancyArrowPatch
from PIL import Image

def draw(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    colors={'ink':'#182a38','blue':'#355f7a','orange':'#a45d19','line':'#83929e','fill':'#f2f5f7','white':'#ffffff'}
    illustration={'coordinate_status':'Two schematic standardized perturbable coordinates; no observed data','rho':1.0,'base_std':[0.9,0.4],'sample_factors':[0.4,0.8],'means':[[-0.65,0.42],[0.35,-0.42]],'query':[0.85,0.67],'contour':'unit Mahalanobis contour of the displayed 2D Gaussian covariance','random_sampling':'none','covariance_rule':'Sigma_i = rho^2 c_i^2 diag(h^2)','geometry_role':'Illustrates input representations and shared covariance axis ratios, not kernel contours, calibration or performance.'}

    def box(ax,x,y,w,h,title,body):
        patch=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.008,rounding_size=0.012',facecolor=colors['fill'],edgecolor=colors['line'],lw=0.85,transform=ax.transAxes)
        ax.add_patch(patch)
        ax.text(x+.017,y+h-.026,title,ha='left',va='top',fontsize=8.4,fontweight='bold',transform=ax.transAxes,color=colors['ink'])
        ax.text(x+.017,y+.030,body,ha='left',va='bottom',fontsize=8.5,linespacing=1.5,transform=ax.transAxes,color=colors['ink'])

    rc={'font.family':'DejaVu Sans','font.size':9,'mathtext.fontset':'stix','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white','figure.facecolor':'white','axes.unicode_minus':False}
    with mpl.rc_context(rc):
        fig=plt.figure(figsize=(150/25.4,90/25.4))
        ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_axis_off()
        ax.text(.035,.972,'(a) Covariance design',fontsize=10,fontweight='bold',va='top',color=colors['ink'])
        ax.text(.555,.972,'(b) Training inputs and a query',fontsize=9.4,fontweight='bold',va='top',color=colors['ink'])
        # Independent sources connect to one factor combination; no sequential arrows.
        box(ax,.045,.711,.394,.174,'Supplied feature metadata',r'Mask $r_j$; relative budget $q_j$'+'\n'+r'Group membership $g(j)$')
        box(ax,.045,.493,.394,.157,'Clean training reference',r'Sample factor $c_i$')
        box(ax,.045,.275,.394,.157,'Labeled, clean validation',r'Global scale $\rho$; group weights $\omega_g$')
        for y in [.798,.5715,.3535]:
            ax.plot([.448,.485],[y,y],lw=1.0,color=colors['blue'],transform=ax.transAxes)
        ax.plot([.485,.485],[.226,.798],lw=1.0,color=colors['blue'],transform=ax.transAxes)
        ax.add_patch(FancyArrowPatch((.485,.226),(.278,.180),arrowstyle='-|>',mutation_scale=9,linewidth=1,color=colors['blue'],connectionstyle='angle,angleA=180,angleB=-90,rad=3',transform=ax.transAxes))
        ax.text(.265,.170,'Diagonal training covariance',ha='center',va='top',fontsize=8.7,fontweight='bold',color=colors['ink'])
        ax.text(.265,.098,r'$\mathbf{\Sigma}_i=\mathrm{diag}_{j}\!\left[(\rho c_i r_j q_j\omega_{g(j)})^2\right]$',ha='center',va='center',fontsize=11.5,color=colors['ink'])
        ax.text(.265,.027,r'$r_j=0\ \mathrm{or}\ q_j=0\quad\Rightarrow\quad\mathrm{zero\ variance}$',ha='center',va='center',fontsize=9,color=colors['ink'])
        ax.plot([.525,.525],[.055,.913],lw=.65,color='#cbd3d9',transform=ax.transAxes)
        # Input-space contours are not RBF-kernel contours or uncertainty calibration.
        plane=fig.add_axes([.605,.355,.365,.495])
        plane.set_xlim(-1.45,1.5);plane.set_ylim(-1.12,1.12);plane.set_aspect('equal')
        plane.set_xticks([]);plane.set_yticks([])
        for spine in ['top','right']:plane.spines[spine].set_visible(False)
        for spine in ['bottom','left']:
            plane.spines[spine].set_color(colors['line']);plane.spines[spine].set_linewidth(.8)
        plane.set_xlabel('Perturbable coordinate 1',fontsize=8.2,labelpad=5,color=colors['ink'])
        plane.set_ylabel('Perturbable coordinate 2',fontsize=8.2,labelpad=5,color=colors['ink'])
        for ind,(mean,c) in enumerate(zip(illustration['means'],illustration['sample_factors'])):
            std=illustration['rho']*c*np.array(illustration['base_std'])
            col=[colors['blue'],colors['orange']][ind]
            plane.add_patch(Ellipse(mean,2*std[0],2*std[1],angle=0,facecolor='none',edgecolor=col,linestyle=['solid','--'][ind],linewidth=1.5))
            plane.scatter([mean[0]],[mean[1]],s=15,marker=['o','^'][ind],facecolor=col,edgecolor=col,zorder=4)
        plane.annotate(r'$P_i$: smaller $c_i$',xy=illustration['means'][0],xytext=(-1.39,.86),fontsize=8.0,color=colors['blue'],ha='left',va='center')
        plane.annotate(r'$P_k$: larger $c_k$',xy=illustration['means'][1],xytext=(-.70,-.92),fontsize=8.0,color=colors['orange'],ha='left',va='center')
        z=illustration['query'];plane.scatter([z[0]],[z[1]],s=27,c=colors['ink'],marker='D',zorder=5)
        plane.text(z[0]+.12,z[1]+.02,r'$\mathbf{z}$',fontsize=10,va='center',color=colors['ink'])
        ax.text(.777,.270,'Same candidate: shared covariance axis ratios',ha='center',fontsize=7.9,color=colors['ink'])
        ax.text(.777,.213,r'Query: point mass $\delta_{\mathbf{z}}$; covariance $0$',ha='center',fontsize=8.8,color=colors['ink'])
        ax.text(.777,.140,'Normalized expected-kernel comparison',ha='center',fontsize=8.0,color=colors['ink'])
        ax.text(.777,.079,r'$\widetilde{k}(P_i,\delta_{\mathbf{z}})$',ha='center',fontsize=13,color=colors['ink'])
        ax.text(.777,.030,'Illustrative geometry; no sampled replicas',ha='center',fontsize=7.9,color=colors['ink'])
        for ext in ['pdf','svg','png']:
            fig.savefig(out/f'covariance_design.{ext}',dpi=600,bbox_inches=None,pad_inches=0,facecolor='white')
        plt.close(fig)

    def contrast(hex1,hex2):
        def luminance(h):
            v=[int(h[i:i+2],16)/255 for i in (1,3,5)]
            linear=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
            return sum(a*b for a,b in zip([.2126,.7152,.0722],linear))
        a,b=sorted([luminance(hex1),luminance(hex2)],reverse=True)
        return (a+.05)/(b+.05)

    report={'figure_type':'conceptual illustration','width_mm':150,'height_mm':90,
            'matplotlib':mpl.__version__,'numpy':np.__version__,
            'illustration_parameters':illustration,'performance_data_used':False,
            'png_pixels':list(Image.open(out/'covariance_design.png').size),
            'scope':'Shared axis ratios and query representation are illustrative; no measured data, kernel contours or sensor calibration.'}
    (out/'covariance_design_provenance.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
