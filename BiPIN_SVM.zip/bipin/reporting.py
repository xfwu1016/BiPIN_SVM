"""Table reconstruction from repetition-level metrics."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t

METRICS = ["balanced_accuracy", "macro_f1", "auc"]


def write_main_tables(raw, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    raw.to_csv(out / "results_raw.csv", index=False)
    summary = raw.groupby(["dataset", "method"], as_index=False).agg(
        balanced_accuracy_mean=("balanced_accuracy", "mean"),
        balanced_accuracy_std=("balanced_accuracy", "std"),
        macro_f1_mean=("macro_f1", "mean"),
        macro_f1_std=("macro_f1", "std"),
        auc_mean=("auc", "mean"), auc_std=("auc", "std"),
        train_time_mean=("train_time", "mean"), rho_mean=("rho", "mean"),
    )
    summary.to_csv(out / "results_summary.csv", index=False)
    records = []
    utilities = []
    for dataset, group in raw.groupby("dataset"):
        for metric in METRICS + ["utility"]:
            data = group.copy()
            if metric == "utility":
                data[metric] = data.balanced_accuracy + 0.25 * data.macro_f1
            pivot = data.pivot(index="seed", columns="method", values=metric)
            diff = pivot["BiPIN-EK"] - pivot["Clean-RBF"]
            n = len(diff)
            half = float(t.ppf(0.975, n - 1) * diff.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
            row = {"dataset": dataset, "metric": metric, "mean_difference": float(diff.mean()),
                   "ci_low": float(diff.mean() - half), "ci_high": float(diff.mean() + half), "n": n}
            if metric == "utility":
                row.pop("metric")
                utilities.append(row)
            else:
                records.append(row)
    paired = pd.DataFrame(records)
    paired["metric"] = pd.Categorical(paired.metric, categories=METRICS, ordered=True)
    paired.sort_values(["metric", "dataset"]).to_csv(out / "paired_ci.csv", index=False)
    pd.DataFrame(utilities).to_csv(out / "utility_gain.csv", index=False)
    return summary


def aggregate_main(raw_csv: Path, out: Path):
    raw = pd.read_csv(raw_csv)
    if raw.duplicated(["dataset", "seed", "method"]).any():
        raise ValueError("Duplicate dataset/seed/method keys")
    return write_main_tables(raw, out)
