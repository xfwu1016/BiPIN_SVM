"""Behavioral checks for the distributional kernel used by the study."""
from pathlib import Path
import os
import unittest

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parents[1] / "runs/.mplconfig"))

import numpy as np
from bipin.core import expected_rbf_kernel, clean_rbf_kernel


class KernelBehaviorTests(unittest.TestCase):
    def test_unit_diagonal_at_underflow_sensitive_covariance(self):
        x = np.zeros((2, 30))
        variance = np.array([[0.7549432157547901] * 30, [0.7569432157547901] * 30])
        kernel = expected_rbf_kernel(x, x, variance, variance, 1.0)
        np.testing.assert_allclose(np.diag(kernel), 1.0, rtol=0, atol=1e-12)

    def test_positive_semidefinite_for_heterogeneous_covariances(self):
        rng = np.random.default_rng(734)
        x = rng.normal(size=(11, 5))
        variance = np.exp(rng.normal(size=x.shape))
        kernel = expected_rbf_kernel(x, x, variance, variance, 0.8)
        np.testing.assert_allclose(kernel, kernel.T, atol=1e-12)
        self.assertGreaterEqual(float(np.linalg.eigvalsh(kernel).min()), -1e-10)

    def test_zero_covariance_reduces_to_rbf_for_rectangular_queries(self):
        rng = np.random.default_rng(910)
        train, query = rng.normal(size=(7, 4)), rng.normal(size=(3, 4))
        actual = expected_rbf_kernel(query, train, np.zeros_like(query), np.zeros_like(train), 1.2)
        expected = clean_rbf_kernel(query, train, 1.2)
        np.testing.assert_allclose(actual, expected, rtol=1e-12, atol=1e-12)

    def test_point_query_is_not_the_broadened_training_kernel(self):
        train = np.array([[0.0, 0.0], [0.8, -0.3]])
        query = np.array([[0.0, 0.0], [0.2, 0.6]])
        p, sigma2, lengthscale = 2, 0.7, 1.1
        variance = np.full_like(train, sigma2)
        l2 = lengthscale ** 2
        training = expected_rbf_kernel(train, train, variance, variance, lengthscale)
        np.testing.assert_allclose(training, clean_rbf_kernel(train, train, np.sqrt(l2 + 2 * sigma2)), atol=1e-12)
        point = expected_rbf_kernel(query, train, np.zeros_like(query), variance, lengthscale)
        amplitude = (1 + sigma2 / l2) ** (-p / 2) * (1 + 2 * sigma2 / l2) ** (p / 4)
        expected = amplitude * clean_rbf_kernel(query, train, np.sqrt(l2 + sigma2))
        np.testing.assert_allclose(point, expected, atol=1e-12)
        self.assertLess(float(point[0, 0]), 1.0)
        self.assertFalse(np.allclose(point, clean_rbf_kernel(query, train, np.sqrt(l2 + 2 * sigma2))))


if __name__ == "__main__":
    unittest.main()
